let currentQuestion = "";

function nextQuestion() {
    fetch('/get_question', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: subject })
    })
    .then(response => response.json())
    .then(data => {
        currentQuestion = data.question;
        document.getElementById('question').textContent = currentQuestion;
        document.getElementById('answer').value = '';
        document.getElementById('result').textContent = '';
    });
}

function submitAnswer() {
    const answer = document.getElementById('answer').value;
    fetch('/check_answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: subject, answer: answer, question: currentQuestion })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('result').textContent = data.result;
        document.getElementById('score').textContent = data.score;
    });
}